package com.luv2code.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.luv2code.hibernate.demo.entity.Student;

public class ReadStudentDemo {

	public static void main(String[] args) {
	   // create session factory
		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class)
				.buildSessionFactory();
		//create a session
		Session session = factory.getCurrentSession();
		try {
			// use the session object to save object
			System.out.println("Creating new Studnet object..");
			Student tempStudent = new Student("Daffy","Duck","daffy@dubey.com");
			// create the student object 
			session.beginTransaction();
			
			// start the student objbect
			System.out.println("saving the student...");
			session.save(tempStudent);
			
			// my new Code
			
			//find out the student id : Primary key
			System.out.println("saved student: generated id :" +tempStudent.getId());
           // now get  new session and start transaction
			session= factory.getCurrentSession();
			// retrieve student based on the id
			System.out.println("\n Getting the student with id: "+tempStudent.getId());
			
			Student myStudent = session.get(Student.class, tempStudent.getId());
			System.out.println("get Complete: "+myStudent);
			// commit the transation
			// commit transaction
			session.getTransaction().commit();
		}
		finally {
			factory.close();
		}

	}

}
