package com.luv2code.hibernate.demo;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.luv2code.hibernate.demo.entity.Student;



public class QueryStudentDemo {

	public static void main(String[] args) {
	   // create session factory
		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class)
				.buildSessionFactory();
		//create a session
		Session session = factory.getCurrentSession();
		try {
			
			session.beginTransaction();
			//Query the student
			List<Student> theStudents = session.createQuery("from Student").list();
			//display the student
			displayStudents(theStudents);
			// query student: lastname ="doe"
			theStudents = session.createQuery("from Student s where s.lastName ='Doe'").list();
			// display students
			System.out.println("\n\n student with the last name doe: ");
			displayStudents(theStudents);
			
			// query student : last name doe or firstname = daffy
			
			theStudents = session.createQuery("from Student s where s.lastName='Doe' OR s.firstName='Daffy'").list();
			// display student
			displayStudents(theStudents);
			
			//  Check email type
			
			theStudents = session.createQuery("from Student s where s.email LIKE '%luv2code.com'").list();
			// display student
						displayStudents(theStudents);
			// commit transaction
			session.getTransaction().commit();
		}
		finally {
			factory.close();
		}

	}

	private static void displayStudents(List<Student> theStudents) {
		for(Student tempStudent : theStudents) {
			System.out.println(tempStudent);
			
		}
	}

}
