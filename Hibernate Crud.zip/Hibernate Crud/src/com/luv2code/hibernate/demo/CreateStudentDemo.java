package com.luv2code.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.luv2code.hibernate.demo.entity.Student;

public class CreateStudentDemo {

	public static void main(String[] args) {
	   // create session factory
		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class)
				.buildSessionFactory();
		//create a session
		Session session = factory.getCurrentSession();
		try {
			// use the session object to save object
			System.out.println("Creating new Studnet object..");
			Student tempStudent = new Student("paul","wall","paulwall@luv2code.com");
			// create the student object 
			session.beginTransaction();
			
			// start the student objbect
			System.out.println("saving the student...");
			session.save(tempStudent);
			
			// commit transaction
			session.getTransaction().commit();
		}
		finally {
			factory.close();
		}

	}

}
