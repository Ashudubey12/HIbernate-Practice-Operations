package com.luv2code.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.luv2code.hibernate.demo.entity.Student;

public class PrimaryKeyDemo {

	public static void main(String[] args) {
		// create session factory
				SessionFactory factory = new Configuration()
						.configure("hibernate.cfg.xml")
						.addAnnotatedClass(Student.class)
						.buildSessionFactory();
				//create a session
				Session session = factory.getCurrentSession();
				try {
					// use the session object to save object
					System.out.println("Creating 3 Studnet object..");
					Student tempStudent1 = new Student("john","doe","john@luv2code.com");
					Student tempStudent2 = new Student("mary","public","mary@luv2code.com");
					Student tempStudent3 = new Student("bonita","apple","bonita@luv2code.com");
					// create 3 student object 
					session.beginTransaction();
					
					// start the student objbect
					System.out.println("saving the student...");
					session.save(tempStudent1);
					session.save(tempStudent2);
					session.save(tempStudent3);
					
					// commit transaction
					session.getTransaction().commit();
				}
				finally {
					factory.close();
				}

			}

	}


