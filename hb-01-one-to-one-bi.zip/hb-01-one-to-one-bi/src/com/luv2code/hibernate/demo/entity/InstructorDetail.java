package com.luv2code.hibernate.demo.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="instructor_detail")
public class InstructorDetail {
	// annonate the class as an entity and map to db table
	
	// define the fields
	// annotate the fields with db columns names
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="youtube_channel")	
    private String youtuneChannel;
	@Column(name="hobby")
    private String hobby;
   // add new field for instructor
	@OneToOne(mappedBy="instructorDetail", cascade = CascadeType.ALL)
	private Instructor instructor;
	
	
	public Instructor getInstructor() {
		return instructor;
	}
	public void setInstructor(Instructor instructor) {
		this.instructor = instructor;
	}
	// create constructor 
	public InstructorDetail(){
		
	}
	public InstructorDetail(String youtuneChannel, String hobby) {
		this.youtuneChannel = youtuneChannel;
		this.hobby = hobby;
	}
	//genrate getter and setter 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getYoutuneChannel() {
		return youtuneChannel;
	}
	public void setYoutuneChannel(String youtuneChannel) {
		this.youtuneChannel = youtuneChannel;
	}
	public String getHobby() {
		return hobby;
	}
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	// genrate toSting()
	
	@Override
	public String toString() {
		return "InstructorDetail [id=" + id + ", youtuneChannel=" + youtuneChannel + ", hobby=" + hobby + "]";
	}
	
	
	
	


}
